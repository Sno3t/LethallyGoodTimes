# Lethal Company mods for friends
If you read this you got the big gay